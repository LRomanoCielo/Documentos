---
title: Features Especiais Cielo
---

Está documentação é um compêndio de novas features lançadas pela Cielo.<br>
Caso deseje utiliza-las entre em contato com a Equipe de PRODUTOS CIELO, e obtenha as credênciais necessarias para a integração.

### **Documentações disponiveis**

**API CIELO ECOMMERCE**

1. **Consulta Bins** - _Permite a busca de informações sobre o cartão. Disponivel apenas para Lojas cadastradas junto a Produtos Cielo._
2. **Zero Auth** - _Valida se cartão é real. Disponivel apenas para Lojas cadastradas junto a Produtos Cielo._
3. **MPI Externo** - _Permite usar um MPI proprio com a API 3.0 Cielo._

---

**CHECKOUT CIELO**

1. **Pré-Cadastro** - _Permite a criação de lojas Checkout Cielo. Disponivel apenas para Plataformas cadastradas junto a Produtos Cielo._ 
2. **Link de Paagamentos** - _Permite a Criação de links de Pagamentos/QR Codes/Botões via API. Disponivel apenas para Plataformas cadastradas junto a Produtos Cielo._